from datetime import datetime, timedelta, timezone
from typing import Optional
import uuid

from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import os
import requests as _requests
from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_requests

from app.db.database import get_db
from app.db.models import User

# ── Config ─────────────────────────────────────────────
from app.config import IS_PRODUCTION

_DEFAULT_SECRET = "changeme-use-env-var-in-production"
SECRET_KEY = os.getenv("JWT_SECRET_KEY", _DEFAULT_SECRET)
if IS_PRODUCTION and (not SECRET_KEY or SECRET_KEY == _DEFAULT_SECRET):
    raise RuntimeError(
        "JWT_SECRET_KEY must be set to a strong secret in production "
        "(the default value is not allowed)."
    )
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 1 week
RESET_TOKEN_EXPIRE_MINUTES = 15
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")
oauth2_scheme_optional = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)

# ── Token revocation (in-memory; cleared on server restart) ───────────────────
# Maps jti → expiry timestamp so we can prune expired entries.
_revoked_jtis: dict[str, float] = {}


def revoke_token(jti: str, exp: float) -> None:
    _revoked_jtis[jti] = exp
    # Prune already-expired entries to keep the set small
    now = datetime.now(timezone.utc).timestamp()
    stale = [k for k, v in _revoked_jtis.items() if v < now]
    for k in stale:
        del _revoked_jtis[k]


def _is_revoked(jti: str) -> bool:
    return jti in _revoked_jtis


# ── Password helpers ───────────────────────────────────
def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# ── JWT helpers ────────────────────────────────────────
def create_access_token(user_id: int, expires_delta: Optional[timedelta] = None) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return jwt.encode(
        {"sub": str(user_id), "exp": expire, "jti": str(uuid.uuid4())},
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def create_password_reset_token(email: str, expires_delta: Optional[timedelta] = None) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=RESET_TOKEN_EXPIRE_MINUTES)
    )
    return jwt.encode(
        {
            "sub": email.strip().lower(),
            "purpose": "password_reset",
            "exp": expire,
            "jti": str(uuid.uuid4()),
        },
        SECRET_KEY,
        algorithm=ALGORITHM,
    )


def verify_password_reset_token(token: str) -> str:
    credentials_exception = HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="Invalid or expired reset token.",
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("purpose") != "password_reset":
            raise credentials_exception
        email = payload.get("sub")
        jti = payload.get("jti", "")
        if not email or (jti and _is_revoked(jti)):
            raise credentials_exception
        return str(email)
    except JWTError:
        raise credentials_exception


# ── Google token verification ────────────────────────
def verify_google_token(token: str) -> dict:
    """Verify a Google ID token and return the payload (sub, email, name)."""
    try:
        info = google_id_token.verify_oauth2_token(
            token,
            google_requests.Request(),
            GOOGLE_CLIENT_ID,
        )
        return info
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid Google token: {e}",
        )


# ── Current user dependency ────────────────────────────
async def resolve_user_from_token(
    token: Optional[str],
    db: AsyncSession,
) -> Optional[User]:
    """Decode a token and return the User row, or None on any failure.

    Single source of truth for the "optional auth" paths (REST optional-user
    dependency and the voice WebSocket). Honors the in-memory revocation list.
    """
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        jti: str = payload.get("jti", "")
        if user_id is None:
            return None
        if jti and _is_revoked(jti):
            return None
        result = await db.execute(select(User).where(User.id == int(user_id)))
        return result.scalar_one_or_none()
    except (JWTError, ValueError):
        return None


async def get_optional_user(
    token: Optional[str] = Depends(oauth2_scheme_optional),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    """Returns the authenticated User if a valid Bearer token is present, None otherwise."""
    return await resolve_user_from_token(token, db)


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        jti: str = payload.get("jti", "")
        if user_id is None:
            raise credentials_exception
        if jti and _is_revoked(jti):
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    result = await db.execute(select(User).where(User.id == int(user_id)))
    user = result.scalar_one_or_none()
    if user is None:
        raise credentials_exception
    return user


def decode_token_payload(token: str) -> dict:
    """Decode a token without raising — returns empty dict on failure."""
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        return {}
